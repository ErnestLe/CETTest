import java.io.*;
import java.util.*;

class WordsForDoubleChoices {
    ArrayList<String> first_eng = new ArrayList<String>();
    ArrayList<String> second_eng = new ArrayList<String>();
    ArrayList<String> first_chi = new ArrayList<String>();
    ArrayList<String> second_chi = new ArrayList<String>();
    WordsForDoubleChoices(String path) {
        BufferedReader bufferedreader = null;
        try {
            bufferedreader = new BufferedReader(new InputStreamReader(new FileInputStream(path),"gbk"));
            while(true) {
                String oneline = bufferedreader.readLine();
                if(oneline==null) break;
                String regex = "[\\s]+";
                String [] words = oneline.split(regex);
                if(words.length < 4) continue;
                first_eng.add(words[0]);
                second_eng.add(words[1]);
                first_chi.add(words[2]);
                second_chi.add(words[3]);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        finally {
            try{
                bufferedreader.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}

