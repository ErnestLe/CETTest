import java.io.*;
import java.util.*;

public class WordsForQuadraChoices {
    ArrayList<String> first_eng = new ArrayList<String>();
    ArrayList<String> second_eng = new ArrayList<String>();
    ArrayList<String> third_eng = new ArrayList<String>();
    ArrayList<String> fourth_eng = new ArrayList<String>();
    ArrayList<String> first_chi = new ArrayList<String>();
    ArrayList<String> second_chi = new ArrayList<String>();
    ArrayList<String> third_chi = new ArrayList<String>();
    ArrayList<String> fourth_chi = new ArrayList<String>();
    WordsForQuadraChoices(String path) {
        BufferedReader bufferedreader = null;
        try {
            bufferedreader = new BufferedReader(new InputStreamReader(new FileInputStream(path),"gbk"));
            while(true) {
                String oneline = bufferedreader.readLine();
                if(oneline == null) break;
                String regex = "[\\s]+";
                String [] words = oneline.split(regex);
                if(words.length < 8) continue;
                first_eng.add(words[0]);
                second_eng.add(words[1]);
                third_eng.add(words[2]);
                fourth_eng.add(words[3]);
                first_chi.add(words[4]);
                second_chi.add(words[5]);
                third_chi.add(words[6]);
                fourth_chi.add(words[7]);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        finally {
            try{
                bufferedreader.close();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}
