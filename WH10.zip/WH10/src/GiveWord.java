import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class GiveWord implements Runnable {
	private final int SingleTimes = 10;
	private final int MultiTimes = 5;
    private Console console;  				//控制台
    private WordsForSingleChoice single;  	//单选
    private WordsForDoubleChoices doubl;	//双选
    private WordsForTripleChoices triple;	//三选
    private WordsForQuadraChoices quadra;	//四选
    private WordsForPentaChoices penta;		//五选
  
    GiveWord(Console frame) {		//初始化
        this.console = frame;
        single  = new WordsForSingleChoice("C:\\Users\\Administrator\\Desktop\\CET6.txt");
        doubl = new WordsForDoubleChoices("C:\\Users\\Administrator\\Desktop\\CET6d.txt");
        triple = new WordsForTripleChoices("C:\\Users\\Administrator\\Desktop\\CET6t.txt");
        quadra = new WordsForQuadraChoices("C:\\Users\\Administrator\\Desktop\\CET6q.txt");
        penta = new WordsForPentaChoices("C:\\Users\\Administrator\\Desktop\\CET6p.txt");
    }
    
    private int getRandomForDouble() {
        int size = doubl.first_eng.size();
        return (int)(Math.random()*size);
    }
    private int getRandomForTriple() {
        int size = triple.first_eng.size();
        return (int)(Math.random()*size);
    }
    private int getRandomForQuadra() {
        int size = quadra.first_eng.size();
        return (int)(Math.random()*size);
    }
    private int getRandomForPenta() {
        int size = penta.first_eng.size();
        return (int)(Math.random()*size);
    }
    @Override
    public void run() {
        while(console.getTimes()<=15) {
        	ArrayList<Integer> indexs = new ArrayList<Integer>();
        	
            if(console.getTimes()<15)
            	console.assure.setEnabled(true);
            
            console.youranswer.setText(null);  		//清空输入框
            console.realresult.setText(null);  	   //清空上一题答案
            console.setAccuracy();   				 //显示正确率
            console.setColor();    					//恢复原来的颜色
            //结束时将提交按钮关闭
            if(console.getTimes()==15){
                console.assure.setEnabled(false);   
            }
            

            if(console.getSingleTimes()<SingleTimes) {
                if(console.getSingleTimes()==SingleTimes)  continue;
                console.addTimes();   	  //增加总做题次数
                console.addSingleTimes();     //增加单选题做题次数
                console.ismultichoices = false;    //设置当前为单选题
                console.setRealAnsNum(1);		//正确答案数是1
                HashMap<String, String> choices = single.getChoices();                //获取需要的5对中英文释义
                ArrayList<Map.Entry<String, String>> list = 
                		new ArrayList<Map.Entry<String, String>>(choices.entrySet());             
                int index = (int) (Math.random()*100)%5;	//随机获取一个为本题答案
                String style = console.getStyle();			//获取模式     
                
                if(style.equals("英译中")) {	 //测试模式为英译中
                    console.question.setText(list.get(index).getKey());
                    console.setAnswer(list.get(index).getValue());
                    console.labelA.setText(list.get(0).getValue());
                    console.labelB.setText(list.get(1).getValue());
                    console.labelC.setText(list.get(2).getValue());
                    console.labelD.setText(list.get(3).getValue());
                    console.labelE.setText(list.get(4).getValue());
                }              
                else if(style.equals("中译英")) {		//测试模式为中译英
                    console.question.setText(list.get(index).getValue());
                    console.setAnswer(list.get(index).getKey());
                    console.labelA.setText(list.get(0).getKey());
                    console.labelB.setText(list.get(1).getKey());
                    console.labelC.setText(list.get(2).getKey());
                    console.labelD.setText(list.get(3).getKey());
                    console.labelE.setText(list.get(4).getKey());
                }
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } else {
                if(console.getMultiTimes()==MultiTimes)  continue;
                int selects = (int) (Math.random()*100)%4 + 2;	//决定二/三/四/五选
                
                if(selects==2) {					//二选                
                	console.addTimes();     //增加总做题次数
                	console.addMultiTimes();     //增加多选题做题次数
                	console.ismultichoices = true;     //设置当前为多选题
                	console.setRealAnsNum(2);	//二选               	
                	ArrayList<String> englishword1 = new ArrayList<String>();		//这是正确的
                	ArrayList<String> englishword2 = new ArrayList<String>();
                	ArrayList<String> chineseword1 = new ArrayList<String>();
                	ArrayList<String> chineseword2 = new ArrayList<String>();
                	for (int i = 0; i < 4 ; i++) {  	//保证随机获得的4个样本不重复z只需要4个
                		int index = getRandomForDouble();
                		while(indexs.contains(index)) {
                        index = getRandomForDouble();
                		}
                		indexs.add(index);
                		englishword1.add(doubl.first_eng.get(index));
                		englishword2.add(doubl.second_eng.get(index));
                		chineseword1.add(doubl.first_chi.get(index));
                		chineseword2.add(doubl.second_chi.get(index));
                	}               
                	int index = (int) (Math.random()*100)%4;	 //随机获取一个为本题答案
                	String style = console.getStyle();
                	if(style.equals("英译中")) {
                		console.question.setText(englishword1.get(index));
                		console.setAnswer(chineseword1.get(index)+","+chineseword2.get(index));
                		ArrayList<String> list = new ArrayList<String>();
                		list.add(chineseword1.get(index));
                		list.add(chineseword2.get(index));
                		for(int i=0;i<4;i++){
                			if(i!=index){
                				list.add(chineseword1.get(i));
                			}
                		}
                		Collections.shuffle(list);	//打乱选项
                		console.labelA.setText(list.get(0));
                		console.labelB.setText(list.get(1));
                		console.labelC.setText(list.get(2));
                		console.labelD.setText(list.get(3));
                		console.labelE.setText(list.get(4));
                	}
                	else if(style.equals("中译英")) {
                		console.question.setText(chineseword1.get(index));
                		console.setAnswer(englishword1.get(index)+","+englishword2.get(index));                   
                		ArrayList<String> list = new ArrayList<String>(); //存放需要的5个选项
                		list.add(englishword1.get(index));
                    	list.add(englishword2.get(index));
                    	for(int i=0;i<4;i++){
                    		if(i!=index){
                    			list.add(englishword1.get(i));
                    		}
                    	}
                    	Collections.shuffle(list);
                    	console.labelA.setText(list.get(0));
                    	console.labelB.setText(list.get(1));
                    	console.labelC.setText(list.get(2));
                    	console.labelD.setText(list.get(3));
                    	console.labelE.setText(list.get(4));
                	}
                	try {
                		Thread.sleep(10000);
                	} catch (InterruptedException e) {
                  	 e.printStackTrace();
                	}
                }
                else if(selects==3) {		//三选
                	console.addTimes();     //增加总做题次数
                	console.addMultiTimes();     //增加多选题做题次数
                	console.ismultichoices = true;     //设置当前为多选题
                	console.setRealAnsNum(3);	//三选               	
                	ArrayList<String> englishword1 = new ArrayList<String>();		//这是正确的
                	ArrayList<String> englishword2 = new ArrayList<String>();
                	ArrayList<String> englishword3 = new ArrayList<String>();
                	ArrayList<String> chineseword1 = new ArrayList<String>();
                	ArrayList<String> chineseword2 = new ArrayList<String>();
                	ArrayList<String> chineseword3 = new ArrayList<String>();
                	for (int i = 0; i < 3 ; i++) {  	//保证随机获得的3个样本不重复z只需要3个
                		int index = getRandomForTriple();
                		while(indexs.contains(index)) {
                        index = getRandomForTriple();
                		}
                		indexs.add(index);
                		englishword1.add(triple.first_eng.get(index));
                		englishword2.add(triple.second_eng.get(index));
                		englishword3.add(triple.third_eng.get(index));
                		chineseword1.add(triple.first_chi.get(index));
                		chineseword2.add(triple.second_chi.get(index));
                		chineseword3.add(triple.third_chi.get(index));
                	}                
                	int index = (int) (Math.random()*100)%3;	 //随机获取一个为本题答案
                	String style = console.getStyle();
                	if(style.equals("英译中")) {
                		console.question.setText(englishword1.get(index));
                		console.setAnswer(chineseword1.get(index)+","+chineseword2.get(index)
                			+","+chineseword3.get(index));
                		ArrayList<String> list = new ArrayList<String>();
                		list.add(chineseword1.get(index));
                		list.add(chineseword2.get(index));
                		list.add(chineseword3.get(index));
                		for(int i=0;i<3;i++){
                			if(i!=index){
                				list.add(chineseword1.get(i));
                			}
                		}
                		Collections.shuffle(list);	//打乱选项
                		console.labelA.setText(list.get(0));
                		console.labelB.setText(list.get(1));
                		console.labelC.setText(list.get(2));
                		console.labelD.setText(list.get(3));
                		console.labelE.setText(list.get(4));
                	}
                	else if(style.equals("中译英")) {
                		console.question.setText(chineseword1.get(index));
                		console.setAnswer(englishword1.get(index)+","+englishword2.get(index)+","
                				+englishword3.get(index));                  
                		ArrayList<String> list = new ArrayList<String>(); //存放需要的3个选项
                		list.add(englishword1.get(index));
                    	list.add(englishword2.get(index));
                    	list.add(englishword3.get(index));
                    	for(int i=0;i<3;i++){
                    		if(i!=index){
                    			list.add(englishword1.get(i));
                    		}
                    	}
                    	Collections.shuffle(list);
                    	console.labelA.setText(list.get(0));
                    	console.labelB.setText(list.get(1));
                    	console.labelC.setText(list.get(2));
                    	console.labelD.setText(list.get(3));
                    	console.labelE.setText(list.get(4));
                	}
                	try {
                		Thread.sleep(10000);
                	} catch (InterruptedException e) {
                  	 e.printStackTrace();
                	}
                }
                else if(selects==4) {
                	console.addTimes();     //增加总做题次数
                	console.addMultiTimes();     //增加多选题做题次数
                	console.ismultichoices = true;     //设置当前为多选题
                	console.setRealAnsNum(4);	//四选                	
                	ArrayList<String> englishword1 = new ArrayList<String>();		//这是正确的
                	ArrayList<String> englishword2 = new ArrayList<String>();
                	ArrayList<String> englishword3 = new ArrayList<String>();
                	ArrayList<String> englishword4 = new ArrayList<String>();
                	ArrayList<String> chineseword1 = new ArrayList<String>();
                	ArrayList<String> chineseword2 = new ArrayList<String>();
                	ArrayList<String> chineseword3 = new ArrayList<String>();
                	ArrayList<String> chineseword4 = new ArrayList<String>();
                	for (int i = 0; i < 2 ; i++) {  	//保证随机获得的3个样本不重复z只需要3个
                		int index = getRandomForQuadra();
                		while(indexs.contains(index)) {
                        index = getRandomForQuadra();
                		}
                		indexs.add(index);
                		englishword1.add(quadra.first_eng.get(index));
                		englishword2.add(quadra.second_eng.get(index));
                		englishword3.add(quadra.third_eng.get(index));
                		englishword4.add(quadra.fourth_eng.get(index));
                		chineseword1.add(quadra.first_chi.get(index));
                		chineseword2.add(quadra.second_chi.get(index));
                		chineseword3.add(quadra.third_chi.get(index));
                		chineseword4.add(quadra.fourth_chi.get(index));
                	}               
                	int index = (int) (Math.random()*100)%2;	 //随机获取一个为本题答案
                	String style = console.getStyle();
                	if(style.equals("英译中")) {
                		console.question.setText(englishword1.get(index));
                		console.setAnswer(chineseword1.get(index)+","+chineseword2.get(index)
                		+","+chineseword3.get(index)+","+chineseword4.get(index));
                		ArrayList<String> list = new ArrayList<String>();
                		list.add(chineseword1.get(index));
                		list.add(chineseword2.get(index));
                		list.add(chineseword3.get(index));
                		list.add(chineseword4.get(index));
                		for(int i=0;i<2;i++){
                			if(i!=index){
                				list.add(chineseword1.get(i));
                			}
                		}
                		Collections.shuffle(list);	//打乱选项
                		console.labelA.setText(list.get(0));
                		console.labelB.setText(list.get(1));
                		console.labelC.setText(list.get(2));
                		console.labelD.setText(list.get(3));
                		console.labelE.setText(list.get(4));
                	}
                	else if(style.equals("中译英")) {
                		console.question.setText(chineseword1.get(index));
                		console.setAnswer(englishword1.get(index)+","+englishword2.get(index)
                		+","+englishword3.get(index)+","+englishword4.get(index));                   
                		ArrayList<String> list = new ArrayList<String>(); //存放需要的3个选项
                		list.add(englishword1.get(index));
                    	list.add(englishword2.get(index));
                    	list.add(englishword3.get(index));
                    	list.add(englishword4.get(index));
                    	for(int i=0;i<2;i++){
                    		if(i!=index){
                    			list.add(englishword1.get(i));
                    		}
                    	}
                    	Collections.shuffle(list);
                    	console.labelA.setText(list.get(0));
                    	console.labelB.setText(list.get(1));
                    	console.labelC.setText(list.get(2));
                    	console.labelD.setText(list.get(3));
                    	console.labelE.setText(list.get(4));
                	}            	
                	try {//等待10秒钟
                		Thread.sleep(10000);
                	} catch (InterruptedException e) {
                  	 e.printStackTrace();
                	}         	
                }
                else if(true) {
                	console.addTimes();     //增加总做题次数
                	console.addMultiTimes();     //增加多选题做题次数
                	console.ismultichoices = true;     //设置当前为多选题
                	console.setRealAnsNum(5);	//wu选                	
                	ArrayList<String> englishword1 = new ArrayList<String>();		//这是正确的
                	ArrayList<String> englishword2 = new ArrayList<String>();
                	ArrayList<String> englishword3 = new ArrayList<String>();
                	ArrayList<String> englishword4 = new ArrayList<String>();
                	ArrayList<String> englishword5 = new ArrayList<String>();
                	ArrayList<String> chineseword1 = new ArrayList<String>();
                	ArrayList<String> chineseword2 = new ArrayList<String>();
                	ArrayList<String> chineseword3 = new ArrayList<String>();
                	ArrayList<String> chineseword4 = new ArrayList<String>();
                	ArrayList<String> chineseword5 = new ArrayList<String>();
                	if(true) {
                        int index = getRandomForPenta();
                		indexs.add(index);
                		englishword1.add(penta.first_eng.get(index));
                		englishword2.add(penta.second_eng.get(index));
                		englishword3.add(penta.third_eng.get(index));
                		englishword4.add(penta.fourth_eng.get(index));
                		englishword5.add(penta.fifth_eng.get(index));
                		chineseword1.add(penta.first_chi.get(index));
                		chineseword2.add(penta.second_chi.get(index));
                		chineseword3.add(penta.third_chi.get(index));
                		chineseword4.add(penta.fourth_chi.get(index));
                		chineseword5.add(penta.fifth_chi.get(index));
                	}
                	int index = 0;
                	String style = console.getStyle();
                	if(style.equals("英译中")) {
                		console.question.setText(englishword1.get(index));
                		console.setAnswer(chineseword1.get(index)+","+chineseword2.get(index)+","
                				+chineseword3.get(index)+","+chineseword4.get(index)+","+chineseword5.get(index));
                		ArrayList<String> list = new ArrayList<String>();
                		list.add(chineseword1.get(index));
                		list.add(chineseword2.get(index));
                		list.add(chineseword3.get(index));
                		list.add(chineseword4.get(index));
                		list.add(chineseword5.get(index));
                		Collections.shuffle(list);	//打乱选项
                		console.labelA.setText(list.get(0));
                		console.labelB.setText(list.get(1));
                		console.labelC.setText(list.get(2));
                		console.labelD.setText(list.get(3));
                		console.labelE.setText(list.get(4));
                	}
                	else if(style.equals("中译英")) {	 //设置本题的问题和答案            
                		console.question.setText(chineseword1.get(index));
                		console.setAnswer(englishword1.get(index)+","+englishword2.get(index)+","
                				+englishword3.get(index)+","+englishword4.get(index)+","+englishword5.get(index));
                        ArrayList<String> list = new ArrayList<String>(); //存放需要的3个选项
                		list.add(englishword1.get(index));
                    	list.add(englishword2.get(index));
                    	list.add(englishword3.get(index));
                    	list.add(englishword4.get(index));
                    	list.add(englishword5.get(index));
                    	Collections.shuffle(list);
                    	console.labelA.setText(list.get(0));
                    	console.labelB.setText(list.get(1));
                    	console.labelC.setText(list.get(2));
                    	console.labelD.setText(list.get(3));
                    	console.labelE.setText(list.get(4));
                	}              	
                	try {//等待10秒钟
                		Thread.sleep(10000);
                	} catch (InterruptedException e) {
                  	 e.printStackTrace();
                	}         	
                }
            }
        }
    }
}
